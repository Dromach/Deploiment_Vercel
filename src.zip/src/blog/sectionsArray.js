export const sections = [
    { title: 'Home', url: '/'},
    { title: 'Technology', url: 'Technology' },
    { title: 'Design', url: 'Design' },
    { title: 'Culture', url: 'Culture' },
    { title: 'Business', url: 'Business' },
    { title: 'Politics', url: 'Politics' },
    { title: 'Opinion', url: 'Opinion' },
    { title: 'Science', url: 'Science' },
    { title: 'Health', url: 'Health' },
    { title: 'Style', url: 'Style' },
    { title: 'Travel', url: 'Travel' },
  ];